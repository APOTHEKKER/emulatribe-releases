$ErrorActionPreference = "Stop"

if ([Environment]::Is64BitOperatingSystem) {
    $inf = Join-Path $PSScriptRoot "driver\x64\KORGUM64.INF"
}
else {
    $inf = Join-Path $PSScriptRoot "driver\x86\KORGUMDN.INF"
}

Write-Host "Installing KORG USB-MIDI Driver..."
Write-Host "INF: $inf"

& pnputil.exe /add-driver $inf /install

if ($LASTEXITCODE -ne 0) {
    Write-Error "KORG driver installation failed. pnputil exit code: $LASTEXITCODE"
    exit $LASTEXITCODE
}

Write-Host "KORG USB-MIDI Driver installation completed."
exit 0